package com.example.ht2019;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.ht2019.ui.makeprofile.MakeProfileFragment;

public class MakeProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.make_profile_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, MakeProfileFragment.newInstance())
                    .commitNow();
        }
    }
}
