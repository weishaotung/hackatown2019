package com.example.ht2019.ui.makeprofile;

import android.arch.lifecycle.ViewModel;

public class MakeProfileViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
